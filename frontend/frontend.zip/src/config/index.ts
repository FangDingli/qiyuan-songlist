export default {
  api: {
    dev: "/devServer",
    prod: "http://8.136.112.243:8003"
  }
}